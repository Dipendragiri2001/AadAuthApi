﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AadAuthApi.TokenAuthentication
{
    public class Token
    {
        public string TokenValue { get; set; }
        public DateTime ExipryDate { get; set; }
    }
}
