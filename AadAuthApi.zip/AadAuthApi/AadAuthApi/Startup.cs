using AadAuthApi.Data;
using AadAuthApi.TokenAuthentication;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace AadAuthApi
{
    public class Startup
    {

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddAutoMapper(typeof(AutoMapperProfile));
            services.AddTransient<ITokenManager, TokenManager>();
            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
           .AddMicrosoftIdentityWebApi(options =>
           {
               Configuration.Bind("AzureAd", options);

               options.TokenValidationParameters.NameClaimType = "name";
               options.TokenValidationParameters.RoleClaimType = "role";
               options.Events = new JwtBearerEvents
               {
                   OnTokenValidated = async ctx =>
                   {
                       string oid = ctx.Principal.FindFirstValue("http://schemas.microsoft.com/identity/claims/objectidentifier");

                       var db = ctx.HttpContext.RequestServices.GetRequiredService<AadAuthApiContext>();
                       var objectIdGuid = Guid.Parse(oid);
                       var user = await db.Users.FirstOrDefaultAsync(a => a.ObjectId == objectIdGuid);
                       var userClaims = db.UserClaims.Where(x => x.UserId == user.Id.ToString());

                       if (user != null)
                       {
                           var claims = new List<Claim>();
                           foreach (var claim in userClaims)
                           {
                               claims.Add(new Claim(claim.ClaimType, claim.ClaimValue));
                           }
                           var appIdentity = new ClaimsIdentity(claims, "MyTestAppIdentity");

                           ctx.Principal.AddIdentity(appIdentity);
                       }
                   }
               };

           },
            options => { Configuration.Bind("AzureAd", options); });
            // o =>
            //{
            //    o.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            //    o.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;

            //})
            //.AddJwtBearer(o =>
            //{ 
            //    o.TokenValidationParameters = new TokenValidationParameters
            //    {
            //        ValidateIssuerSigningKey = true,
            //        IssuerSigningKey = new SymmetricSecurityKey(Encoding.ASCII.GetBytes("12345678910111121314151617181920212223343536373839303132")),
            //        ValidateLifetime = true,
            //        ValidateAudience = false,
            //        ValidateIssuer = false,
            //        ClockSkew = TimeSpan.Zero
            //    };
            //});
            services.AddAuthorization(options =>
            {
                options.AddPolicy("MustBeAdmin", policy => policy.RequireClaim(ClaimTypes.Role, "Admin"));
            });
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "AadAuthApi", Version = "v1" });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "AadAuthApi v1"));
            }
            app.UseCors(builder => builder.AllowAnyOrigin()
            .AllowAnyMethod().AllowAnyHeader());
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
