﻿using AadAuthApi.TokenAuthentication;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AadAuthApi.Controllers
{   
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly ITokenManager tokenManager;

        public AuthenticateController(ITokenManager tokenManager)
        {
            this.tokenManager = tokenManager;
        }

        public IActionResult Authenticate(string user,string pwd)
        {
            if(tokenManager.Authenticate(user,pwd))
            {
                return Ok(new { Token = tokenManager.NewToken() });

            }
            else
            {
                ModelState.AddModelError("Unauthorized", "You are not authorized");
                return Unauthorized(ModelState);
            }
        }
    }
}
