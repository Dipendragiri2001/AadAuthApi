﻿using AadAuthApi.Data;
using AadAuthApi.Dtos;
using AadAuthApi.Filters;
using AadAuthApi.Models;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AadAuthApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[TokenAuthenticationFilter]
    [Authorize]
    public class CustomersController : ControllerBase
    {
        private readonly AadAuthApiContext _context;
        private readonly UserManager<AadAuthApiUser> _userManager;
        private readonly IHttpContextAccessor _httpContext;
        private IMapper Mapper;
        private readonly Microsoft.AspNetCore.Identity.SignInManager<AadAuthApiUser> _signInManager;

        public CustomersController(AadAuthApiContext context,
            UserManager<AadAuthApiUser> userManager,
            IHttpContextAccessor httpContext,
            SignInManager<AadAuthApiUser> signInManager, IMapper mapper)
        {
            _context = context;
            _userManager = userManager;
            _httpContext = httpContext;
            _signInManager = signInManager;
            Mapper = mapper;
        }

        [HttpGet]
        [Route("adduser")]
        public async Task<IActionResult> AddUser()
        {
            string oid = _httpContext.HttpContext.User.Claims.First(e => e.Type == "http://schemas.microsoft.com/identity/claims/objectidentifier").Value;

            
            var objectId = Guid.Parse(oid);
           
            AadAuthApiUser u = new AadAuthApiUser
            {
                ObjectId = objectId,
                Name = "Dipendra Giri",
                Email = "dipendra.giri@alphaventus.com",
                UserName = "dipendra.giri@alphaventus.com"
            };

             var user = await _userManager.CreateAsync(u);
             if(user.Succeeded)
            {
                await AddClaim();
                return Ok(user);
            }
            else
            {
                return BadRequest(user.Errors);
            }
        }

        public async Task AddClaim()
        {
            Claim claim = new Claim(ClaimTypes.Role, "Admin");
            AadAuthApiUser user = await _userManager.FindByEmailAsync("dipendra.giri@alphaventus.com");
            await _userManager.AddClaimAsync(user, claim);

        }
        [HttpPost]
        [Authorize]
        [Route("loginuser")]
        public async Task<IActionResult> Login(string email, string password)
        {
            _httpContext.HttpContext.User.Claims.ToList();
            var user = await _context.Users.FirstOrDefaultAsync(
                           x => x.Email == email);
            var userClaims = _context.UserClaims.Where(x => x.UserId == user.Id.ToString());
            if (user != null)
            {
                var claims = new List<Claim>();
                foreach (var c in userClaims)
                {
                    claims.Add(new Claim(ClaimTypes.Role, c.ClaimValue));
                }
                var appIdentity = new ClaimsIdentity(claims);
                _httpContext.HttpContext.User.AddIdentity(appIdentity);
                await _signInManager.SignInAsync(user,true);
            }

            return Ok(user);
            
        }
        [Authorize(Policy ="MustBeAdmin")]
        [HttpGet]
        public IActionResult GetCustomers()
        {
            var customer = _context.Customers.ToList().FirstOrDefault();
            var mapping = Mapper.Map<CustomerDto>(customer);
            return Ok(mapping);
        }
    }
}
