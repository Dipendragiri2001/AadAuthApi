﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace AadAuthApi.Data
{
    // Add profile data for application users by adding properties to the AadAuthApiUser class
    public class AadAuthApiUser : IdentityUser
    {
        public Guid ObjectId { get; set; }
        public string Name { get; set; }
    }
}
