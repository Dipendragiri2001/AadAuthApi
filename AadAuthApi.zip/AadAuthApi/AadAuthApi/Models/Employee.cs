﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AadAuthApi.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public decimal Salary { get; set; }
        public string JobTitle { get; set; }
        public DateTime HireDate { get; set; }
        public decimal LastPaidAmount { get; set; }
        public DateTime LastPaidDate { get; set; }
        public decimal TotalPaidAmount { get; set; }
    }
}
